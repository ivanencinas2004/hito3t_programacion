package com.empresa.model;

public class Cliente {
	public String nombre;
	public String correo;
	public float peso_actual;
	public int horas_extra;
	public int eventos;
	public Cliente(String nombre, String correo, float peso_actual, int horas_extra, int eventos) {
		super();
		this.nombre = nombre;
		this.correo = correo;
		this.peso_actual = peso_actual;
		this.horas_extra = horas_extra;
		this.eventos = eventos;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public float getPeso_actual() {
		return peso_actual;
	}
	public void setPeso_actual(float peso_actual) {
		this.peso_actual = peso_actual;
	}
	public int getHoras_extra() {
		return horas_extra;
	}
	public void setHoras_extra(int horas_extra) {
		this.horas_extra = horas_extra;
	}
	public int getEventos() {
		return eventos;
	}
	public void setEventos(int eventos) {
		this.eventos = eventos;
	}
	
	
	
}
