package com.empresa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.empresa.model.Cliente;

public class ClienteDao {
	private String endpoint="jdbc:mysql://localhost:3306/test?useSSL=false";
	private String user="root";
	private String pass="";
	
	public Connection conectar() {
		 Connection connection =null;
	
		 try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 connection = DriverManager.getConnection(endpoint, user, pass);
	 } catch (ClassNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
	 } catch (SQLException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
     }
		return connection;
	}
	public void insertCliente(Cliente c) {
        
        // try-with-resource statement will auto close the connection.
         
        	Connection connection = conectar();
        	PreparedStatement ps;
			try {
				ps = connection.prepareStatement("INSERT INTO solocrossfit (id, nombre, correo, peso_actual, horas_extra, eventos) VALUES (NULL,?,?,?,?,?);");
	        	ps.setString(1, c.getNombre());
	        	ps.setString(2, c.getCorreo());
	        	ps.setFloat(3, c.getPeso_actual());
	        	ps.setInt(4, c.getHoras_extra());
	        	ps.setInt(5, c.getEventos());
	        	
	        	
	        	ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
	}//cierra insertar
}
