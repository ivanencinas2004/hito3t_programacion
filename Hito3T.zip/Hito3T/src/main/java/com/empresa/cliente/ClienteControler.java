package com.empresa.cliente;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.dao.ClienteDao;
import com.empresa.model.Cliente;

/**
 * Servlet implementation class ClienteControler
 */
@WebServlet("/")
public class ClienteControler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClienteControler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		switch (action) {
		case "/add":
			addCliente(request, response );
			break;

		default:
			listCliente(request, response );
			break;
		}//cierra el switch
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}//cierra el doGet

	private void listCliente(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void addCliente(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		//int id=Integer.parseInt(request.getParameter("id"));
		String nombre=request.getParameter("nombre");
		String correo=request.getParameter("correo");
		Float peso_actual=Float.parseFloat(request.getParameter("peso_actual"));
		int horas_extra=Integer.parseInt(request.getParameter("horas_extra"));
		int eventos	=Integer.parseInt(request.getParameter("eventos"));
		
		Cliente cliente=new Cliente(nombre, correo, peso_actual, horas_extra, eventos);
		ClienteDao dao=new ClienteDao();
		dao.insertCliente(cliente);
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}